// data.js — semua variabel dari VB (RiplayData.Build) untuk template HTML.
// Ditulis ulang tiap Generate Riplay. Dimuat PageN.html / AllBody.html / PageAssembler lewat <script src="data.js">.
// Boleh diedit lalu klik Generate PDF (atau --assemble) untuk menyusun ulang AllPages tanpa mengulang import.
window.riplayData = {
  "riders": [
    "FEC"
  ],
  "funds": [
    {
      "fundname": "Manulife Dana Ekuitas",
      "funddesc": "dana ekuitas",
      "fundrisk": "Sedang"
    },
    {
      "fundname": "Manulife Dana Sejahtera",
      "funddesc": "dana sejahtera",
      "fundrisk": "Tinggi"
    },
    {
      "fundname": "Manulife Dana Umum",
      "funddesc": "dana umum",
      "fundrisk": "Rendah"
    }
  ],
  "footer": {
    "agentname": "Budi",
    "agentcode": "A123",
    "proposalnumber": "P-001",
    "printdate": "13/09/2026",
    "expireddate": "13/10/2026"
  }
};
